/*
Created		06/09/2011
Modified		06/09/2011
Project		
Model			
Company		
Author		
Version		
Database		MS SQL 2005 
*/


Create table [Entity1]
(
	[CASA] Char(1) NOT NULL,
	[DOD] Char(1) NULL,
Primary Key ([CASA])
) 
go

Create table [Entity3]
(
	[CASASSSSS] Char(1) NOT NULL,
	[TRES] Char(1) NULL,
Primary Key ([CASASSSSS])
) 
go

Create table [Entity4]
(
	[CASA] Char(1) NOT NULL,
	[CASASSSSS] Char(1) NOT NULL,
Primary Key ([CASA],[CASASSSSS])
) 
go


Alter table [Entity4] add  foreign key([CASA]) references [Entity1] ([CASA])  on update no action on delete no action 
go
Alter table [Entity4] add  foreign key([CASASSSSS]) references [Entity3] ([CASASSSSS])  on update no action on delete no action 
go


Set quoted_identifier on
go


Set quoted_identifier off
go


/* Roles permissions */


/* Users permissions */


