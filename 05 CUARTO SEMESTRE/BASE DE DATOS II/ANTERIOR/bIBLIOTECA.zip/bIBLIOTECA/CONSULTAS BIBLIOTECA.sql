--1. Desplegar el nombre de los usuarios que pidieron prestado el libro
--   "Fundamentos de bases de datos" de Korth el mes de agosto del 2011.

SELECT * FROM LIBRO
SELECT * FROM PRESTAMO

SELECT NOMBRE,TITULO,FECHAENTREGA FROM USUARIO INNER JOIN LIBRO L 
ON  L.titulo='FUNDAMENTOS DE BASE DE DATOS' 
--WHERE  NOMBRE <> NOMBRE
INNER JOIN PRESTAMO P
ON MONTH(P.FECHAENTREGA)=08 

--2. Desplegar todos los t�tulos de los libros que no se han prestado.

SELECT *FROM PRESTAMO 
SELECT * FROM LIBRO
SELECT * FROM COPIALIBRO

SELECT ESTADO,ID_libro FROM PRESTAMO P INNER JOIN COPIALIBRO L INNER JOIN LIBRO LI
ON LI.ID_libro = L.ID_libro
INNER JOIN COPIALIBRO C
WHERE C.ESTADO = 'DISPONIBLE'  

--3. Nombre y apellido de cada autor con el n�mero de libros escritos ordenado de mayor a menor.

SELECT * FROM AUTOR INNER JOIN AUT_LIB AL INNER JOIN LIBRO L
ON AL.ID_libro = L.ID_libro
INNER JOIN AUTOR A
 ORDER BY  A.NOMBRE

--4. Nombre y apellido de los usuarios que no han entregado los libro a tiempo.

SELECT * FROM USUARIO
SELECT * FROM COPIALIBRO
SELECT * FROM HISTORICO

SELECT NOMBRE,APELLIDO,MULTA FROM HISTORICO AS H INNER JOIN USUARIO AS U
ON H.ID_USUARIO=U.ID_usuario AND MULTA<>0 

--5. T�tulo de los libros que est�n rprestados por mas de 5 dias.

SELECT * FROM LIBRO 
SELECT * FROM PRESTAMO

SELECT TITULO,DIASPRESTAMO FROM LIBRO AS L INNER JOIN PRESTAMO AS P INNER JOIN COPIALIBRO AS C
ON P.DIASPRESTAMO > 5 AND C.ID_COPIA=P.ID_COPIA

--6. Nombre del autor que ha escrito mas libros.

SELECT * FROM AUT_LIB
SELECT * FROM LIBRO

SELECT NOMBRE,COUNT (ID_AUTOR) from AUTOR INNER JOIN AUT_LIB AS AL INNER JOIN LIBRO AS L
ON AL.ID_LIBRO=L.ID_LIBRO

--7. T�tulo de cada libro junto con el n�mero de veces que se ha prestado.

--8. Copias del libro Programaci�n de Deitel que est�n disponibles.


--9. Nombres y apellidos de los j�venes que han hecho reservaciones.

SELECT * FROM USUARIO
SELECT * FROM JOVEN
SELECT * FROM RESERVA

SELECT NOMBRE,APELLIDO FROM  USUARIO AS U INNER JOIN JOVEN AS J
ON J.ID_USUARIO=U.ID_USUARIO 
INNER JOIN RESERVA AS R
ON J.ID_USUARIO = R.ID_USUARIO


--10. Nombre y apellido de los deudores con su deuda acumulada.

SELECT * FROM USUARIO
SELECT * FROM COPIALIBRO
SELECT * FROM HISTORICO

SELECT NOMBRE,APELLIDO FROM HISTORICO AS H INNER JOIN USUARIO AS U
ON H.ID_USUARIO=U.ID_usuario AND MULTA<>0 