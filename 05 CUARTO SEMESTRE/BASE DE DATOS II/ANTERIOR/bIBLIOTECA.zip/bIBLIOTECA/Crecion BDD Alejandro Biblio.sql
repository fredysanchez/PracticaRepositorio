---MODELO ALEJANDRO CORREGIDO

CREATE TABLE USUARIO 
(
ID_usuario int IDENTITY (1,1) not null,
nombre varchar(100),
apellido varchar(100),
CONSTRAINT [PK_USUARIO] PRIMARY KEY CLUSTERED 
(
	[ID_usuario] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE ADULTO (
foto int,
fechaIngreso datetime,
ID_usuario INT PRIMARY KEY,
)
DROP TABLE ADULTO
ALTER TABLE ADULTO ADD FOREIGN KEY(ID_usuario) REFERENCES USUARIO (ID_usuario)


CREATE TABLE JOVEN
(
ID_usuario INT PRIMARY KEY,
ID_garante  INT  references ADULTO (ID_usuario),
fechaNacimiento dateTIME,
)
DROP TABLE JOVEN

ALTER TABLE JOVEN ADD FOREIGN KEY(ID_usuario) REFERENCES USUARIO (ID_usuario)

CREATE TABLE LIBRO 
(
ID_libro int IDENTITY (1,1),
titulo nvarchar(50),
editorial nvarchar(50),
tipolibro nvarchar(50),
a�opublicacion datetime,
CONSTRAINT [PK_LIBRO] PRIMARY KEY CLUSTERED 
(
	[ID_libro] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE COPIALIBRO 
(
ID_copia int IDENTITY (1,1) primary key,
numerocopias nvarchar(10),
estado nvarchar(50),
ID_libro int,
--PRIMARY KEY (ID_libro),
)
drop table COPIALIBRO
ALTER TABLE COPIALIBRO ADD FOREIGN KEY(ID_libro) REFERENCES LIBRO (ID_libro)

CREATE TABLE AUTOR
(
ID_autor int identity (1,1),
nombre NVARCHAR(50),
apellido NVARCHAR(50),
CONSTRAINT [PK_AUTOR] PRIMARY KEY CLUSTERED 
(
	[ID_autor] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]



CREATE TABLE AUT_LIB 
(
ID_autor int,
ID_libro int,
PRIMARY KEY (ID_autor,ID_libro),
)
Alter table [AUT_LIB] add  foreign key([ID_autor]) references [AUTOR] ([ID_autor])  on update no action on delete no action 
go
Alter table [AUT_LIB] add  foreign key([ID_libro]) references [LIBRO] ([ID_libro])  on update no action on delete no action 
go

CREATE TABLE RESERVA (
ID_reserva int identity (1,1) primary key,
ID_usuario int,
ID_libro int,
fechareserva datetime,
unique (ID_reserva,ID_usuario,ID_libro),
FOREIGN KEY(ID_usuario) REFERENCES USUARIO (ID_usuario),
FOREIGN KEY(ID_libro) REFERENCES LIBRO (ID_libro)
)


CREATE TABLE PRESTAMO (
ID_prestamo int IDENTITY (1,1) PRIMARY KEY,
diasprestamo nvarchar(50),
fechadevolucion dateTIME,
fechaentrega dateTIME,
ID_usuario int,
ID_copia int,
UNIQUE (fechadevolucion,ID_usuario)
)

ALTER TABLE PRESTAMO ADD FOREIGN KEY(ID_usuario) REFERENCES USUARIO (ID_usuario)
ALTER TABLE PRESTAMO ADD FOREIGN KEY(ID_copia) REFERENCES COPIALIBRO (ID_copia)

CREATE TABLE HISTORICO (
--ID_historico integer,
fechaprestamo dateTIME,
fechadevolucion dateTIME,
diasprestamo nVarchar(50),
multa NUMERIC (9,2),
ID_usuario inT,
ID_copia inT,
)

ALTER TABLE HISTORICO ADD FOREIGN KEY(ID_usuario) REFERENCES USUARIO (ID_usuario)
ALTER TABLE HISTORICO ADD FOREIGN KEY(ID_copia) REFERENCES COPIALIBRO (ID_copia)
